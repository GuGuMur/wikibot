# WikiBot
为PRTS和ArcaeaCNWiki提供编辑功能的mediawiki api库，封装了<del>个性化</del>的一些工具

# 使用的bot账号

# 文档