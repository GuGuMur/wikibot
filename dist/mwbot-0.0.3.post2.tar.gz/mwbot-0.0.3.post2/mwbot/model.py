'''储存了一些变量'''
import mwbot.arktool as AK
STAGE_TABLE = AK.read_ark_cn_file("excel/stage_table.json")
ITEM_TABLE = AK.read_ark_cn_file("excel/item_table.json")
GAMEDATA_CONST = AK.read_ark_cn_file("excel/gamedata_const.json")
CHARACTER_TABLE = AK.read_ark_cn_file("excel/character_table.json")
HANDBOOK_INFO = AK.read_ark_cn_file("excel/handbook_info_table.json")
